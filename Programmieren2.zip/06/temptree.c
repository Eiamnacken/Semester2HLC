#include <stdio.h>
#include <stdlib.h>
#include "temptree.h"

void printTreeRec(TempTreeNodePtr root, unsigned int indent);

void insertNode(TempTreeNodePtr* rootptr, int temp, int timestamp){
}

void printTree(TempTreeNodePtr root)
{
	printTreeRec(root, 0);
}

void printTreeRec(TempTreeNodePtr root, unsigned int indent)
{
	unsigned int i = 0;
	if (root == NULL)
		return;
	for (i = 0; i < indent; i++)
		printf("|----");
	printf("T: %d t: %d\n", root->temp, root->timestamp);
	printTreeRec(root->left, indent+1);
	printTreeRec(root->right, indent+1);
}

void freeTree(TempTreeNodePtr root)
{
}

unsigned int countNodes(TempTreeNodePtr root)
{
}

int minTemp(TempTreeNodePtr root)
{
}

int maxTemp(TempTreeNodePtr root)
{
}


double avgTemp(TempTreeNodePtr root)
{
}