// Temperaturmesswerteverwaltung

#include <stdio.h>
#include <stdlib.h>
#include "temptree.h"

int main (void)
{
	unsigned int temp = 0;
	unsigned int timestamp = 0;
	unsigned int i = 0;
	TempTreeNodePtr root = NULL;
	srand(1);
	
	// Initialisiere Suchbaum mit Zufallswerten

	for (i = 0; i < 15; i++)
		insertNode(&root, rand() % 50, i);
	printTree(root);
	printf("Minimum :%d\n", minTemp(root));
	printf("Maximum :%d\n", maxTemp(root));
	printf("Anzahl der Knoten: %d\n", countNodes(root));
	printf("Durchschnitt %4.2f:\n", avgTemp(root));
	freeTree(root);

}
