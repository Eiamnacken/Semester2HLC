
// Struktur fuer binaeren Suchbaum
// speichert Temperaturmesswert und Zeitstempel
// sortiert nach Temperatur
typedef struct temptreenode {
	int temp;
	int timestamp;
	struct temptreenode* left;
	struct temptreenode* right;
} TempTreeNode;

typedef TempTreeNode* TempTreeNodePtr;

/** fuegt Knoten in binaeren Suchbaum ein
  * Schluessel ist die Temperatur
  * Der gleiche Schluessel darf mehrfach im Baum vorkommen
  * @param rootptr Zeiger auf Zeiger auf Wurzelknoten, d.h. Zeiger
  * auf Wurzelknoten wird als Referenz uebergeben
  * @param temp Temperaturmesswert
  * @param timestamp Zeitstempel
 */
void insertNode(TempTreeNodePtr* rootptr, int temp, int timestamp);

/** gibt den vom Suchbaum belegten Speicher auf dem Heap wieder frei
  * @param root Zeiger auf Wurzelknoten
  */
void freeTree(TempTreeNodePtr root);

/** gibt des Baum formatiert auf der Konsole aus
 * @param root Zeiger auf Wurzelknoten
 */
void printTree(TempTreeNodePtr root);

/** zaehlt die im Baum vorhandenen Knoten
  * @param root Zeiger auf Wurzelknoten
  * @returns Anzahl der Knoten im Baum
  */

unsigned int countNodes(TempTreeNodePtr root);

/** bestimmt den minimalen Temperatureintrag
  * @param root Zeiger auf Wurzelknoten
  * @returns minimale gespeicherte Temperatur
  */
int minTemp(TempTreeNodePtr root);

/** bestimmt den maximalen Temperatureintrag
  * @param root Zeiger auf Wurzelknoten
  * @returns maximale gespeicherte Temperatur
  */
int maxTemp(TempTreeNodePtr root);

/** bestimmt den Durchschnitt aller gespeicherten Messwerte
  * @param root Zeiger auf Wurzelknoten
  * @returns Durchschnitt der gespeicherten Messwerte oder
  * -1 falls der Baum leer ist.
  */
double avgTemp(TempTreeNodePtr root);
